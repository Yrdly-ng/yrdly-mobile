# YRDLY store artwork — photography redesign

Version 2 responds to the supplied references with real stock photography, stronger editorial typography, larger phone compositions and varied panel layouts. The reference images were used for visual direction only; their watermarked pixels were not reused.

## Status

These are designed store-artwork drafts. Phone content is reconstructed demonstration UI, not a native device capture. Real photographs replace the generated campaign photography from version 1. Sample listings, prices and community details are illustrative, and people pictured are stock models, not claimed YRDLY users or endorsers. Photographs are not claimed to have been taken in Nigeria.

Native iPhone and Android screenshots remain necessary before submission. No attached device, configured emulator or usable iOS simulator was available; the user confirmed they had no screenshots. No store upload was performed.

## Deliverables

Five panels per store, ten PNGs total: introduction, events, marketplace, local businesses, and communities.

- `apple-phone-draft/`: 1320 × 2868 px PNGs and self-contained HTML layouts.
- `google-phone-draft/`: 1080 × 1920 px PNGs and self-contained HTML layouts.
- `preview.png`: both sets in one contact sheet.
- `source/render.cjs`: rerender with Node using the existing workspace dependencies and installed Chrome.
- `manifest.json`: export dimensions and alpha-channel checks.
- `assets/photo-map.json`: maps each role in the layouts to its photograph.

PNG exports are opaque. Editable composition source and photography source credits are included. The original version remains in the adjacent `store-screenshots` folder.

## References

- Apple dimensions: https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/
- Google asset guidance: https://support.google.com/googleplay/android-developer/answer/9866151?hl=en
- Pexels photography licence: https://www.pexels.com/license/
- Photo-specific authors and links: `assets/photo-sources.json`.

Application code was not changed for this artwork. Existing unrelated changes in the mobile repository were left intact.
