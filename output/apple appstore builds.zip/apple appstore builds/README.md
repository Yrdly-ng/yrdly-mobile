# YRDLY store screenshot artwork

**Status: design drafts, not submission-ready native screenshots.**

Four coordinated panels for each store: events, marketplace, local businesses, and communities. Black / YRDLY green (#82DB7E), Outfit typography, intact screen previews, and independent layouts for each aspect ratio.

## Files

- `apple-iphone-draft/`: four 1320 × 2868 RGB PNGs, plus editable self-contained HTML compositions.
- `google-play-phone-draft/`: four 1080 × 1920 RGB PNGs, plus editable self-contained HTML compositions.
- `preview.png`: side-by-side overview of both sets.
- `manifest.json`: dimensions, alpha validation and provenance per image.
- `source/render.cjs`: repeatable renderer; run with Node from any directory in this workspace. Uses existing product-app Playwright/Sharp packages and installed Chrome.

Upload order, after replacing previews with native captures: 01 events, 02 marketplace, 03 businesses, 04 communities.

## Source and release limitation

Screen previews come from `YRDLY Launch Film/assets/screenshots/*-screen-campaign.png` (1179 × 2556). They use actual React Native Web card components inside reconstructed iOS-like screen wrappers, with previously approved fictional campaign content. They are not captures from the installed iPhone or Android app. Some sample cards repeat. See the film's `assets/campaign/PROVENANCE.md`.

The same preview sources are used in both draft sets. In particular, the Google drafts still contain the source preview's iOS-style home indicator. Replace the entire screen with an Android capture before submission; do not present these drafts as Android captures. Apple drafts likewise need real iPhone captures. No real account data is included.

No connected device, configured Android virtual device, or usable iOS simulator was available during this work. The user confirmed that no iPhone or Android screenshots were available. The renderer can be updated to read separate platform-specific captures when a build can be run on those devices.

Only phone artwork is included; tablet/iPad screenshots require captures at the supported tablet layout. No store upload was performed. Application code was not modified.

## Specifications checked 2026-10-19

- Apple accepts 1320 × 2868 portrait screenshots for large Dynamic Island iPhones, without alpha channels: https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/
- Google recommends at least four portrait images at 1080 × 1920 for screenshot recommendation formats; actual captured app content is required and taglines should occupy no more than 20%: https://support.google.com/googleplay/android-developer/answer/9866151?hl=en

The drafts meet the selected pixel sizes and opaque PNG requirements. They are not certified compliant store submissions because native captures remain outstanding.
